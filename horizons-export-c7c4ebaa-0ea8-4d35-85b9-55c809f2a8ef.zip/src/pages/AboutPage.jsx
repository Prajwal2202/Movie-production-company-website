import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Eye, Users, Sparkles } from 'lucide-react';

const AboutPage = () => {
    return (
        <>
            <Helmet>
                <title>About KVC Productions</title>
                <meta name="description" content="Learn about the mission, values, and team behind KVC Productions, a leader in cinematic storytelling." />
            </Helmet>
            <div className="bg-background text-foreground min-h-screen py-24 sm:py-32">
                <div className="container mx-auto px-6 space-y-24">
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="text-center mb-20">
                            <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                                <span className="gradient-text">About KVC Productions</span>
                            </h1>
                            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
                                We are a dynamic movie production company dedicated to crafting captivating cinematic experiences that resonate with audiences worldwide.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                            <div>
                               <img  
                                    alt="A bustling film set with cameras and crew"
                                    className="w-full h-auto max-h-[500px] rounded-xl shadow-2xl object-cover"
                                 src="https://images.unsplash.com/photo-1703463890291-e65bbfbe358c" />
                            </div>
                            <div className="space-y-6">
                                <h2 className="text-4xl font-cinzel font-semibold text-foreground">Our Company</h2>
                                <p className="text-lg text-muted-foreground leading-relaxed">
                                    KVC Productions was founded with a singular goal: to bring compelling stories to life on the silver screen. We believe in the power of film to entertain, inspire, and provoke thought. Our team is a passionate collective of writers, directors, producers, and technicians who are committed to pushing the boundaries of storytelling.
                                </p>
                                <p className="text-lg text-muted-foreground leading-relaxed">
                                    From gripping dramas to heartwarming comedies and thrilling action, we specialize in a diverse range of genres, always striving for the highest standards of quality in production and narrative.
                                </p>
                            </div>
                        </div>
                    </motion.div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
                        <motion.div whileHover={{ y: -10 }} className="bg-secondary p-10 rounded-xl shadow-lg">
                            <Target className="h-12 w-12 mx-auto mb-6 text-orange-500" />
                            <h3 className="text-2xl font-cinzel font-semibold mb-3">Our Mission</h3>
                            <p className="text-muted-foreground">To produce high-quality, memorable films that leave a lasting impact on audiences and contribute meaningfully to the world of cinema.</p>
                        </motion.div>
                        <motion.div whileHover={{ y: -10 }} className="bg-secondary p-10 rounded-xl shadow-lg">
                            <Eye className="h-12 w-12 mx-auto mb-6 text-orange-500" />
                            <h3 className="text-2xl font-cinzel font-semibold mb-3">Our Vision</h3>
                            <p className="text-muted-foreground">To be a globally recognized production house known for its innovative storytelling, creative excellence, and commitment to nurturing new talent.</p>
                        </motion.div>
                        <motion.div whileHover={{ y: -10 }} className="bg-secondary p-10 rounded-xl shadow-lg">
                            <Users className="h-12 w-12 mx-auto mb-6 text-orange-500" />
                            <h3 className="text-2xl font-cinzel font-semibold mb-3">Our Team</h3>
                            <p className="text-muted-foreground">Our strength lies in our collaborative team of creative professionals who bring diverse perspectives and expertise to every project.</p>
                        </motion.div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AboutPage;