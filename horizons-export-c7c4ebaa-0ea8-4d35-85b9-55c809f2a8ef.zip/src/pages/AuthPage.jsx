import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const AuthPage = () => {
    const [isLogin, setIsLogin] = useState(true);
    const { toast } = useToast();

    const handleSubmit = (e) => {
        e.preventDefault();
        toast({
            title: "🚧 Authentication In Progress",
            description: "This feature isn't fully implemented yet. Please check back later!",
        });
    };

    return (
        <>
            <Helmet>
                <title>{isLogin ? 'Login' : 'Sign Up'} - KVC Productions</title>
                <meta name="description" content="Access your KVC Productions account or create a new one." />
            </Helmet>
            <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-b from-gray-900 via-black to-gray-900 relative">
                 <Link to="/" className="absolute top-8 left-8 text-white hover:text-orange-500 transition-colors flex items-center gap-2 z-10">
                    <ArrowLeft size={18} /> Back to Home
                 </Link>
                <motion.div
                    initial={{ opacity: 0, y: -50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7 }}
                >
                    <Card className="w-[380px] bg-black/30 border-orange-500/30 text-white">
                        <CardHeader className="text-center">
                            <CardTitle className="text-3xl font-cinzel gradient-text">{isLogin ? 'Welcome Back' : 'Create Account'}</CardTitle>
                            <CardDescription className="text-gray-400 pt-2">{isLogin ? 'Log in to continue.' : 'Sign up to get started.'}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                {!isLogin && (
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Name</Label>
                                        <Input id="name" placeholder="Your Name" className="bg-gray-800 border-gray-700 focus:ring-orange-500 focus:border-orange-500" />
                                    </div>
                                )}
                                <div className="space-y-2">
                                    <Label htmlFor="email">Email</Label>
                                    <Input id="email" type="email" placeholder="your.email@example.com" className="bg-gray-800 border-gray-700 focus:ring-orange-500 focus:border-orange-500" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="password">Password</Label>
                                    <Input id="password" type="password" placeholder="••••••••" className="bg-gray-800 border-gray-700 focus:ring-orange-500 focus:border-orange-500" />
                                </div>
                                <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 text-black font-semibold">
                                    {isLogin ? 'Login' : 'Sign Up'}
                                </Button>
                            </form>
                            <p className="text-center text-sm text-gray-400 mt-6">
                                {isLogin ? "Don't have an account?" : "Already have an account?"}
                                <button onClick={() => setIsLogin(!isLogin)} className="font-semibold text-orange-500 hover:underline ml-1">
                                    {isLogin ? 'Sign Up' : 'Login'}
                                </button>
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </>
    );
};

export default AuthPage;