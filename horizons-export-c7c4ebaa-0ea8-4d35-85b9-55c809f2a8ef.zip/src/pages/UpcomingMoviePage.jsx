import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const UpcomingMoviePage = () => {
    return (
        <>
            <Helmet>
                <title>Upcoming Movie - KVC Productions</title>
                <meta name="description" content="A new cinematic experience is coming soon from the creative team behind 'Krishnam Pranaya Sakhi'." />
            </Helmet>
            <div className="min-h-screen flex items-center justify-center p-4 green-bg-gradient relative overflow-hidden">
                <div className="absolute inset-0 z-0">
                    <img  alt="Abstract background with green and fresh loving atmosphere" className="w-full h-full object-cover opacity-20" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/1571de9bd7acbb28498c3332a2548bce.jpg" />
                     <div className="absolute inset-0 bg-black/30"></div>
                </div>
                <div className="text-center text-white relative z-10 p-6">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, ease: "easeOut" }}
                    >
                         <h1 className="text-4xl md:text-6xl font-cinzel font-bold mb-4 text-shadow">
                            Production No. 3
                        </h1>
                        <p className="text-lg md:text-xl text-gray-200 max-w-2xl mx-auto mb-8 text-shadow">
                           A new cinematic experience from the same creative team behind 'Krishnam Pranaya Sakhi', starring Golden Star Ganesh.
                        </p>
                        <div className="relative inline-block">
                           <img  
                                alt="Poster for the upcoming movie starring Golden Star Ganesh"
                                className="w-full max-w-lg h-auto rounded-lg shadow-2xl"
                                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/1571de9bd7acbb28498c3332a2548bce.jpg" />
                        </div>
                        <p className="text-xl mt-8 font-semibold text-gray-200 text-shadow">
                            Coming Soon...
                        </p>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default UpcomingMoviePage;