import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Newspaper, Video, Play, ExternalLink } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const newsArticles = [
    { title: "'Krishnam Pranaya Sakhi' lauded for its fresh take on romance", source: "Cinema Express", link: "#", img: "https://images.unsplash.com/photo-1573948778603-8d9b91c9876a" },
    { title: "Director Srinivas on the making of the 'Dandupalya' saga", source: "Film Companion", link: "#", img: "https://images.unsplash.com/photo-1470074087292-145fb2e0de50" },
    { title: "KVC Productions announces next big project", source: "The Hindu", link: "#", img: "https://images.unsplash.com/photo-1610616817237-dff4b556cce6" },
];

const videoLinks = [
    { title: "Behind the Scenes: Krishnam Pranaya Sakhi", platform: "YouTube", link: "#" },
    { title: "Dandupalya Cast Interview", platform: "YouTube", link: "#" },
    { title: "KVC Productions: A Decade in Cinema", platform: "Vimeo", link: "#" },
];

const NewsPage = () => {
    const { toast } = useToast();

    const handleLinkClick = (title) => {
        toast({
            title: `Navigating to: ${title}`,
            description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    };

    return (
        <>
            <Helmet>
                <title>News & Media - KVC Productions</title>
                <meta name="description" content="Stay updated with the latest news, articles, and video content from KVC Productions." />
            </Helmet>
            <div className="bg-background text-foreground min-h-screen py-24 sm:py-32">
                <div className="container mx-auto px-6">
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="text-center mb-20">
                            <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                                <span className="gradient-text">News & Media Hub</span>
                            </h1>
                            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
                                The latest updates, press coverage, and behind-the-scenes content from the world of KVC Productions.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
                            <div className="space-y-12">
                                <h2 className="text-4xl font-cinzel font-semibold flex items-center gap-4">
                                    <Newspaper className="text-orange-500 h-10 w-10" />
                                    In The Press
                                </h2>
                                {newsArticles.map((article, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, x: -50 }}
                                        whileInView={{ opacity: 1, x: 0 }}
                                        transition={{ duration: 0.6, delay: index * 0.1 }}
                                        viewport={{ once: true }}
                                        className="bg-secondary p-6 rounded-xl shadow-lg flex flex-col sm:flex-row gap-6"
                                    >
                                        <img  alt={article.title} src={article.img} className="w-full sm:w-1/3 h-48 sm:h-auto object-cover rounded-lg" />
                                        <div className="flex flex-col justify-between">
                                            <div>
                                                <p className="text-sm text-muted-foreground mb-2">Source: {article.source}</p>
                                                <h3 className="text-xl font-semibold text-foreground mb-4">{article.title}</h3>
                                            </div>
                                            <Button onClick={() => handleLinkClick(article.title)} variant="outline">
                                                Read Full Article <ExternalLink className="ml-2 h-4 w-4" />
                                            </Button>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>

                            <div className="space-y-12">
                                <h2 className="text-4xl font-cinzel font-semibold flex items-center gap-4">
                                    <Video className="text-orange-500 h-10 w-10" />
                                    Featured Videos
                                </h2>
                                {videoLinks.map((video, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, x: 50 }}
                                        whileInView={{ opacity: 1, x: 0 }}
                                        transition={{ duration: 0.6, delay: index * 0.1 }}
                                        viewport={{ once: true }}
                                        className="bg-secondary p-8 rounded-xl shadow-lg"
                                    >
                                        <h3 className="text-xl font-semibold text-foreground mb-2">{video.title}</h3>
                                        <p className="text-muted-foreground mb-4">Platform: {video.platform}</p>
                                        <Button onClick={() => handleLinkClick(video.title)}>
                                            Watch Video <Play className="ml-2 h-4 w-4" />
                                        </Button>
                                    </motion.div>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default NewsPage;