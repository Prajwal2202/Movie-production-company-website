import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const { toast } = useToast();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "📫 Message Sent!",
      description: "Thank you for reaching out. We'll get back to you soon.",
    });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact Us - KVC Productions</title>
        <meta name="description" content="Get in touch with KVC Productions for inquiries, collaborations, and more." />
      </Helmet>
      <div className="bg-background text-foreground min-h-screen py-24 sm:py-32 flex items-center">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-center mb-20">
              <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                <span className="gradient-text">Contact Us</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
                Have a question, a script, or a proposal? We'd love to hear from you.
              </p>
            </div>

            <div className="flex justify-center">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="bg-secondary p-10 rounded-xl shadow-lg w-full max-w-2xl"
              >
                <h2 className="text-4xl font-cinzel font-semibold mb-8 text-foreground text-center">Send a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <Input name="name" type="text" placeholder="Your Name" value={formData.name} onChange={handleInputChange} className="bg-background" required />
                  <Input name="email" type="email" placeholder="Your Email" value={formData.email} onChange={handleInputChange} className="bg-background" required />
                  <textarea name="message" placeholder="Your Message" value={formData.message} onChange={handleInputChange} rows="6" className="w-full p-3 bg-background border rounded-md text-foreground placeholder-muted-foreground focus:ring-ring focus:border-ring" required></textarea>
                  <Button type="submit" size="lg" className="w-full">
                    <Send className="mr-2 h-5 w-5" /> Send Message
                  </Button>
                </form>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;