import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Clapperboard } from 'lucide-react';

const moviesData = [
    {
        id: 'krishnam-pranaya-sakhi',
        title: "Krishnam Pranaya Sakhi",
        summary: "A beautiful tale of love, destiny, and heartwarming romance.",
        genre: "Romance, Drama",
        imgAlt: "Krishnam Pranaya Sakhi official movie poster",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/c463d09b32025f0985fb98c9db27bc6e.jpg",
    },
    {
        id: 'dandupalya-1',
        title: "Dandupalya 1",
        summary: "The chilling beginning of a brutal saga based on true events.",
        genre: "Crime, Thriller",
        imgAlt: "Dandupalya 1 official movie poster",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/eecdf1633940a4c17090191730802166.jpg",
    },
    {
        id: 'dandupalya-2',
        title: "Dandupalya 2",
        summary: "The reign of terror continues with more gruesome intensity.",
        genre: "Crime, Thriller",
        imgAlt: "Dandupalya 2 official movie poster",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/e094e26b02ccf016f132fff610541d77.jpg",
    },
    {
        id: 'dandupalya-3',
        title: "Dandupalya 3",
        summary: "The gang's dark past and twisted motives are further explored.",
        genre: "Crime, Thriller",
        imgAlt: "Dandupalya 3 official movie poster",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/d01c622ed6474b3b972252942b251e44.jpg",
    },
    {
        id: 'dandupalya-4',
        title: "Dandupalya 4",
        summary: "The final, blood-curdling chapter in the notorious crime saga.",
        genre: "Crime, Thriller",
        imgAlt: "Dandupalya 4 official movie poster",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/357dc34193367e3bc4ce78ee8b0a3b24.jpg",
    },
];

const MoviesListPage = () => {
    return (
        <>
            <Helmet>
                <title>Our Movies - KVC Productions</title>
                <meta name="description" content="Explore the complete filmography of KVC Productions, from gripping thrillers to heartwarming romances." />
            </Helmet>
            <div className="bg-background text-foreground min-h-screen py-24 sm:py-32">
                <div className="container mx-auto px-6">
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="text-center mb-20"
                    >
                        <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                            <span className="gradient-text">Our Filmography</span>
                        </h1>
                        <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
                            A journey through the stories we've passionately brought to the screen. Explore our diverse collection of films.
                        </p>
                    </motion.div>

                    <div className="space-y-24">
                        {moviesData.map((movie, index) => (
                            <motion.div
                                key={movie.id}
                                initial={{ opacity: 0, y: 50 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.7, delay: 0.1 }}
                                viewport={{ once: true }}
                                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center`}
                            >
                                <div className={`relative ${index % 2 !== 0 ? 'lg:order-last' : ''}`}>
                                    <img 
                                        alt={movie.imgAlt}
                                        className="rounded-xl shadow-2xl w-full h-auto object-cover"
                                        src={movie.imgSrc} />
                                </div>
                                <div className="space-y-6 text-center lg:text-left">
                                    <p className="font-semibold text-orange-500 uppercase tracking-wider">{movie.genre}</p>
                                    <h2 className="text-4xl md:text-5xl font-cinzel font-bold text-foreground">{movie.title}</h2>
                                    <p className="text-lg text-muted-foreground leading-relaxed">{movie.summary}</p>
                                    <Link to={`/movie/${movie.id}`}>
                                        <Button size="lg" className="mt-4">
                                            <Clapperboard className="mr-2 h-5 w-5" />
                                            View Details
                                        </Button>
                                    </Link>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default MoviesListPage;