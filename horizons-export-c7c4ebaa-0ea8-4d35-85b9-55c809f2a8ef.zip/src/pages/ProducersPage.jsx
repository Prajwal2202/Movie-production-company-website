import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const producers = [
    {
        name: 'Mr. Samrudhi V Manjunath',
        role: 'Lead Producer',
        description: 'Mr. Samrudhi V Manjunath is a cornerstone of KVC Productions, steering projects from concept to completion with his vast industry experience and sharp business acumen. His leadership ensures that every film meets the highest standards of quality and financial viability.',
        imgAlt: "Professional portrait of producer Mr. Samrudhi V Manjunath",
        imgSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/facfe90a4f077200e48803eeeec503ad.jpg"
    }
];

const ProducersPage = () => {
    return (
        <>
            <Helmet>
                <title>The Producers - KVC Productions</title>
                <meta name="description" content="Meet the key producers, the driving forces behind KVC Productions." />
            </Helmet>
            <div className="bg-background text-foreground min-h-screen py-24 sm:py-32">
                <div className="container mx-auto px-6">
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="text-center mb-20">
                            <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                                <span className="gradient-text">The Minds Behind the Magic</span>
                            </h1>
                            <p className="text-lg md:text-xl text-muted-foreground">Meet the Producer of KVC Productions</p>
                        </div>

                        <div className="space-y-24">
                            {producers.map((producer, index) => (
                                <motion.div
                                    key={producer.name}
                                    className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center"
                                    initial={{ opacity: 0, y: 50 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    transition={{ duration: 0.7 }}
                                    viewport={{ once: true }}
                                >
                                    <div className="relative">
                                       <img  
                                            alt={producer.imgAlt}
                                            className="w-full h-auto max-h-[600px] rounded-xl shadow-2xl object-cover mx-auto"
                                            src={producer.imgSrc} />
                                    </div>
                                    <div className="space-y-6 text-center lg:text-left">
                                        <h2 className="text-4xl md:text-5xl font-cinzel font-semibold text-foreground">{producer.name}</h2>
                                        <h3 className="text-xl text-orange-500 font-semibold uppercase tracking-wider">{producer.role}</h3>
                                        <p className="text-lg text-muted-foreground leading-relaxed">{producer.description}</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </div>
        </>
    );
};

export default ProducersPage;