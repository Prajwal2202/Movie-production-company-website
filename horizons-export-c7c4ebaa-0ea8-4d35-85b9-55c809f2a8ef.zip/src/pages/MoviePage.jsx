import React, { useState } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlayCircle, Ticket, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const moviesData = {
    'krishnam-pranaya-sakhi': {
        title: "Krishnam Pranaya Sakhi",
        summary: "A beautiful tale of love, destiny, and heartwarming romance.",
        trailerUrl: "https://www.youtube.com/embed/t_l9FfmQpsA",
        watchUrl: "https://www.sunnxt.com/kannada-movie-krishnam-pranaya-sakhi-2024/detail/206509",
        bgClass: 'green-bg-gradient',
        posterSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/b0b599173ba83c0f2eac4a25c56defde.jpg",
        posterAlt: "Krishnam Pranaya Sakhi official movie poster",
    },
    'dandupalya-1': {
        title: "Dandupalya 1",
        summary: "The chilling beginning of a brutal saga based on true events.",
        trailerUrl: "https://www.youtube.com/embed/lzM8Rt-m0Yo",
        watchUrl: "https://www.youtube.com/watch?v=LCS6EkMuBvc",
        bgClass: 'fire-bg-gradient',
        posterSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/89fca6832732c5ee00e1d514814990b8.jpg",
        posterAlt: "Dandupalya 1 official movie poster",
    },
    'dandupalya-2': {
        title: "Dandupalya 2",
        summary: "The reign of terror continues with more gruesome intensity.",
        trailerUrl: "https://www.youtube.com/embed/wvfDlzj1-HE",
        watchUrl: "https://www.youtube.com/watch?v=Tf4uGZVlgIo",
        bgClass: 'fire-bg-gradient',
        posterSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/4f38db8478cf3c8c0cfad75de85b771a.jpg",
        posterAlt: "Dandupalya 2 official movie poster",
    },
    'dandupalya-3': {
        title: "Dandupalya 3",
        summary: "The gang's dark past and twisted motives are further explored.",
        trailerUrl: "https://www.youtube.com/embed/9xakWurtMMU",
        watchUrl: "https://www.youtube.com/watch?v=c8bHIh8MVYw",
        bgClass: 'fire-bg-gradient',
        posterSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/d415ca0790a1a7182486cd80966378d1.jpg",
        posterAlt: "Dandupalya 3 official movie poster",
    },
    'dandupalya-4': {
        title: "Dandupalya 4",
        summary: "The final, blood-curdling chapter in the notorious crime saga.",
        trailerUrl: "https://www.youtube.com/embed/iZgFEdjXtN0",
        watchUrl: "https://www.youtube.com/watch?v=LCS6EkMuBvc&t=7s",
        bgClass: 'fire-bg-gradient',
        posterSrc: "https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/97894df89942f329e28bc12cb16cf626.jpg",
        posterAlt: "Dandupalya 4 official movie poster",
    },
};

const MoviePage = () => {
    const { id } = useParams();
    const movie = moviesData[id];
    const { toast } = useToast();
    const [isTrailerOpen, setIsTrailerOpen] = useState(false);

    if (!movie) {
        return <Navigate to="/404" replace />;
    }

    const handleWatchMovie = () => {
        if (movie.watchUrl) {
            window.open(movie.watchUrl, '_blank');
        } else {
            toast({
                title: "Coming Soon to Streaming!",
                description: "This movie is not yet available for streaming. Stay tuned for updates!",
            });
        }
    };

    return (
        <>
            <Helmet>
                <title>{movie.title} - KVC Productions</title>
                <meta name="description" content={movie.summary} />
            </Helmet>
            <div className={`min-h-screen flex items-center justify-center p-4 ${movie.bgClass} relative overflow-hidden`}>
                <div className="absolute inset-0 z-0">
                    <img  alt="Abstract background image related to the movie's theme" className="w-full h-full object-cover opacity-10" src={movie.posterSrc} />
                </div>
                <div className="container mx-auto relative z-10">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
                    >
                        <div className="relative">
                           <img  
                                alt={movie.posterAlt}
                                className="w-full h-auto rounded-lg shadow-2xl max-h-[70vh] object-contain"
                            src={movie.posterSrc} />
                        </div>
                        <div className="text-center md:text-left text-foreground dark:text-white">
                            <h1 className="text-4xl md:text-6xl font-cinzel font-bold mb-4 text-shadow">{movie.title}</h1>
                            <p className="text-xl text-muted-foreground dark:text-gray-200 italic mb-8">"{movie.summary}"</p>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                                <Button size="lg" onClick={() => setIsTrailerOpen(true)} className="bg-gradient-to-r from-orange-500 to-yellow-500 text-black font-semibold hover:scale-105 transition-transform">
                                    <PlayCircle className="mr-2 h-6 w-6" /> Watch Trailer
                                </Button>
                                <Button size="lg" onClick={handleWatchMovie} variant="outline" className="border-2 border-black dark:border-white text-black dark:text-white hover:bg-black dark:hover:bg-white hover:text-white dark:hover:text-black transition-colors">
                                    <Ticket className="mr-2 h-6 w-6" /> {movie.watchUrl ? 'Watch Full Movie' : 'Coming Soon'}
                                </Button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>

            <AnimatePresence>
            {isTrailerOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="modal-backdrop" onClick={() => setIsTrailerOpen(false)}
                >
                    <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        className="modal-content relative w-full max-w-4xl bg-black"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="aspect-w-16 aspect-h-9">
                            <iframe
                                src={movie.trailerUrl}
                                title={`${movie.title} Trailer`}
                                frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                                className="w-full h-full rounded-lg"
                            ></iframe>
                        </div>
                         <Button onClick={() => setIsTrailerOpen(false)} variant="ghost" className="absolute -top-10 -right-2 text-white hover:text-orange-500">
                            <X size={32}/>
                        </Button>
                    </motion.div>
                </motion.div>
            )}
            </AnimatePresence>
        </>
    );
};

export default MoviePage;