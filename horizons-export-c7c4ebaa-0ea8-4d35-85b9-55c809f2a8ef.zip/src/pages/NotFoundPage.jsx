import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Home } from 'lucide-react';

const NotFoundPage = () => {
    return (
        <>
            <Helmet>
                <title>404 - Page Not Found</title>
                <meta name="description" content="The page you are looking for does not exist." />
            </Helmet>
            <div className="min-h-screen flex items-center justify-center text-center p-4 bg-black">
                <motion.div
                    initial={{ opacity: 0, y: -50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7 }}
                    className="space-y-6"
                >
                    <AlertTriangle className="mx-auto h-24 w-24 text-orange-500" />
                    <h1 className="text-6xl font-cinzel font-bold text-white">404</h1>
                    <h2 className="text-3xl font-semibold text-gray-300">Page Not Found</h2>
                    <p className="text-lg text-gray-400 max-w-md mx-auto">
                        Oops! The page you're looking for seems to have gotten lost in the cinematic universe.
                    </p>
                    <Link to="/">
                        <Button size="lg" className="bg-gradient-to-r from-orange-500 to-yellow-500 text-black font-semibold">
                            <Home className="mr-2 h-5 w-5" /> Go Back to Home
                        </Button>
                    </Link>
                </motion.div>
            </div>
        </>
    );
};

export default NotFoundPage;