import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Youtube, X } from 'lucide-react';

const DirectorPage = () => {
    const [isVideoOpen, setIsVideoOpen] = useState(false);
    const interviewUrl = "https://www.youtube.com/embed/X5fwZXon9Pc?si=_XOaUIe08x4VD8vb";

    return (
        <>
            <Helmet>
                <title>About The Director: Mr. Srinivas Raju - KVC Productions</title>
                <meta name="description" content="Meet Mr. Srinivas Raju, the visionary director behind KVC Productions' cinematic creations." />
            </Helmet>
            <div className="bg-background text-foreground min-h-screen py-24 sm:py-32">
                <div className="container mx-auto px-6">
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="text-center mb-20">
                            <h1 className="text-5xl md:text-7xl font-cinzel font-bold mb-6">
                                <span className="gradient-text">The Visionary: Mr. Srinivas Raju</span>
                            </h1>
                            <p className="text-lg md:text-xl text-muted-foreground">Director & Storyteller</p>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
                            <div className="lg:col-span-2">
                                <img  
                                    alt="Professional portrait of director Mr. Srinivas Raju"
                                    className="w-full h-auto rounded-xl shadow-2xl object-cover"
                                 src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/e039a8d310af34cd509cf209a72bb289.jpg" />
                            </div>

                            <div className="lg:col-span-3 space-y-8">
                                <h2 className="text-4xl font-cinzel font-semibold text-foreground">A Journey in Filmmaking</h2>
                                <p className="text-lg text-muted-foreground leading-relaxed">
                                    Mr. Srinivas Raju is a masterful storyteller whose vision has been the driving force behind KVC Productions' most acclaimed films. With a keen eye for detail and a profound understanding of human emotion, he crafts narratives that are both commercially successful and critically revered.
                                </p>
                                <p className="text-lg text-muted-foreground leading-relaxed">
                                    His journey began with a passion for cinema that evolved into a decorated career marked by bold creative choices and an unwavering commitment to quality. From the raw intensity of the "Dandupalya" series to the heartfelt romance of "Krishnam Pranaya Sakhi," Mr. Srinivas Raju has demonstrated remarkable versatility and a unique ability to connect with audiences across genres.
                                </p>
                                <Button onClick={() => setIsVideoOpen(true)} size="lg" className="bg-gradient-to-r from-red-500 to-orange-500 text-white font-semibold hover:scale-105 transition-transform shadow-lg">
                                    <Youtube className="mr-2 h-6 w-6" /> Watch Director's Interview
                                </Button>
                            </div>
                        </div>

                        <div className="mt-24 grid grid-cols-1 md:grid-cols-2 gap-10">
                             <img  
                                alt="Mr. Srinivas Raju directing on a film set"
                                className="w-full h-96 rounded-xl shadow-lg object-cover"
                              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/5dc9fdb9b93e324654a2a6da50e12ce2.jpg" />
                             <img  
                                alt="Mr. Srinivas Raju reviewing a shot on a monitor"
                                className="w-full h-96 rounded-xl shadow-lg object-cover"
                              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/57fb523d43346d6793f6e1437581c55b.webp" />
                        </div>
                    </motion.div>
                </div>
            </div>
            
            <AnimatePresence>
                {isVideoOpen && (
                     <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="modal-backdrop" onClick={() => setIsVideoOpen(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.8, opacity: 0 }}
                            className="modal-content relative w-full max-w-4xl bg-black"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="aspect-w-16 aspect-h-9">
                                <iframe
                                    src={interviewUrl}
                                    title="Director Srinivas Raju Interview"
                                    frameBorder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowFullScreen
                                    className="w-full h-full rounded-lg"
                                ></iframe>
                            </div>
                            <Button onClick={() => setIsVideoOpen(false)} variant="ghost" className="absolute -top-10 -right-2 text-white hover:text-orange-500">
                                <X size={32}/>
                            </Button>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default DirectorPage;