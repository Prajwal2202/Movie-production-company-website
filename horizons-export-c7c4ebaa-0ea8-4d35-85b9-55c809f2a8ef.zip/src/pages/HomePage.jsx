import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Clapperboard, Users, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const featuredMovies = [
  { id: 'krishnam-pranaya-sakhi', title: "Krishnam Pranaya Sakhi", description: 'A fresh and loving romance story', img: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/f5d3edf698328f2a9f480eaec1b3aedb.jpg' },
  { id: 'dandupalya-1', title: "Dandupalya 1", description: 'A gritty and intense crime thriller', img: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/f8fb005f7472e0b7c7ba323d663bdc2d.jpg' },
  { id: 'dandupalya-2', title: "Dandupalya 2", description: 'The brutal sequel to the infamous crime story', img: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/ea3ce0b5f0190662ba455127a5fbef20.jpg' },
];

const slideshowImages = [
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/9dcdd1025d359a49a4c6a3ac2569ae37.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/a89aad6fc1fdce6f5ddfcd040a457edc.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/58ab7435cac07f7bfc170ba688c779cb.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/dda1c69594f53c664f38a71b3b4e958a.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/2c1222e70c40a59ce11e77d4870444fb.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/95f658afc55b040c7d9c0d20bc3a3a16.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/95dfc809890469f984dbef60528cf6f6.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/31a9ec3698cea8b0a9423eff221233f5.webp',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/e74be1d498935cfc383fde683ce4dcfa.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/4fbdd57f7d909c96dd0035b5224feac0.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/b265b96fc821f5fc36db2e7d96b7d961.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/b8910a9519c2dc461bfbbe45740b84bc.jpg',
  'https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/3b559d3f58cdd7c3cf27a94256c67a5b.jpg',
];

const HomePage = () => {
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prevImage) => (prevImage + 1) % slideshowImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-background text-foreground">
      <section className="relative min-h-screen flex items-center justify-center text-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <AnimatePresence>
            <motion.img
              key={currentImage}
              src={slideshowImages[currentImage]}
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.5, ease: 'easeInOut' }}
              className="w-full h-full object-cover"
              alt="Movie scene slideshow"
            />
          </AnimatePresence>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
        </div>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="relative z-10 p-6"
        >
          <h1 className="text-5xl md:text-8xl font-cinzel font-bold mb-6">
            <span className="gradient-text">KVC PRODUCTIONS</span>
          </h1>
          <p className="text-xl md:text-2xl text-foreground/80 max-w-4xl mx-auto mb-10 text-shadow">
            A dynamic movie production company dedicated to crafting captivating cinematic experiences that resonate with audiences worldwide.
          </p>
          <Link to="/movies">
            <Button size="lg" className="bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold hover:scale-105 transition-transform shadow-lg">
              Explore Our Films <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </motion.div>
      </section>

      <section className="py-24 sm:py-32">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-cinzel font-bold mb-4">
              Stories That <span className="gradient-text">Inspire</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We believe in the power of cinema to move hearts and minds. Discover our latest creations.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {featuredMovies.map((movie, index) => (
              <motion.div
                key={movie.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                viewport={{ once: true }}
              >
                <Link to={`/movie/${movie.id}`}>
                  <div className="relative h-96 rounded-xl overflow-hidden group shadow-2xl movie-card-hover">
                     <img  alt={`${movie.title} poster`} className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" src={movie.img} />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-8">
                      <h3 className="text-3xl font-cinzel font-bold text-white text-shadow">{movie.title}</h3>
                      <p className="text-white/80 mt-2">{movie.description}</p>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 sm:py-32 bg-secondary">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-cinzel font-bold">
                <span className="text-orange-500">The</span> <span className="gradient-text">Art of Filmmaking</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                At KVC Productions, every project is a labor of love. We combine innovative storytelling with cutting-edge technology to create unforgettable cinematic journeys. Our mission is to not just make movies, but to create experiences that last a lifetime.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-orange-500/20 text-orange-500 p-3 rounded-full"><Clapperboard /></div>
                  <div>
                    <h4 className="font-bold text-lg">Creative Vision</h4>
                    <p className="text-muted-foreground">Pushing the boundaries of narrative and visual style.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-orange-500/20 text-orange-500 p-3 rounded-full"><Users /></div>
                  <div>
                    <h4 className="font-bold text-lg">Talented Team</h4>
                    <p className="text-muted-foreground">A passionate collective of industry-leading professionals.</p>
                  </div>
                </div>
              </div>
              <Link to="/about">
                <Button size="lg" variant="outline" className="mt-6">
                  Learn More About Us <Sparkles className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div>
              <img  alt="A professional film camera on a movie set" className="rounded-xl shadow-2xl w-full h-auto object-cover" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/c7c4ebaa-0ea8-4d35-85b9-55c809f2a8ef/17566988d0d447328085f85a968d591b.jpg" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;