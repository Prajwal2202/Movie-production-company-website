
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Award, Users, Film } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Hero = () => {
  const { toast } = useToast();

  const handleWatchReel = () => {
    toast({
      title: "🎬 Show Reel Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleExploreWork = () => {
    const moviesSection = document.getElementById('movies');
    if (moviesSection) {
      moviesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img  
          alt="Cinematic movie production scene with dramatic lighting"
          className="w-full h-full object-cover"
         src="https://images.unsplash.com/photo-1703463890291-e65bbfbe358c" />
        <div className="absolute inset-0 hero-gradient"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="max-w-4xl mx-auto"
        >
          <motion.h1
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.2 }}
            className="text-5xl md:text-7xl font-cinzel font-bold mb-6 text-shadow"
          >
            <span className="gradient-text">KVC PRODUCTIONS</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto leading-relaxed"
          >
            Crafting captivating cinematic experiences that resonate with audiences worldwide. 
            From gripping dramas to heartwarming comedies and thrilling action.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            <Button
              onClick={handleWatchReel}
              size="lg"
              className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-black font-semibold px-8 py-3 text-lg"
            >
              <Play className="w-5 h-5 mr-2" />
              Watch Our Reel
            </Button>
            <Button
              onClick={handleExploreWork}
              variant="outline"
              size="lg"
              className="border-2 border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-black px-8 py-3 text-lg"
            >
              <Film className="w-5 h-5 mr-2" />
              Explore Our Work
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto"
          >
            <div className="glass-effect rounded-lg p-6">
              <Award className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-3xl font-bold gradient-text">50+</div>
              <div className="text-gray-300">Awards Won</div>
            </div>
            <div className="glass-effect rounded-lg p-6">
              <Film className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-3xl font-bold gradient-text">100+</div>
              <div className="text-gray-300">Films Produced</div>
            </div>
            <div className="glass-effect rounded-lg p-6">
              <Users className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-3xl font-bold gradient-text">1M+</div>
              <div className="text-gray-300">Happy Viewers</div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 border-2 border-orange-500 rounded-full flex justify-center"
        >
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-1 h-3 bg-orange-500 rounded-full mt-2"
          />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;
