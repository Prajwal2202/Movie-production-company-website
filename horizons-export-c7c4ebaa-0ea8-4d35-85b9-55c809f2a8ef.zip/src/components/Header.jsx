import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, Film, UserCircle, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ThemeToggle } from '@/components/ThemeToggle';
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const dropdownLinks = [{
    name: 'Our Movies',
    path: '/movies'
  }, {
    name: 'The Director',
    path: '/director'
  }, {
    name: 'Upcoming',
    path: '/upcoming'
  }, {
    name: 'The Producers',
    path: '/producers'
  }, {
    name: 'News & Media',
    path: '/news'
  }];
  return <motion.header initial={{
    y: -100
  }} animate={{
    y: 0
  }} className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass-effect shadow-lg' : 'bg-transparent'}`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3">
            <motion.div whileHover={{
            scale: 1.05
          }} className="flex items-center space-x-3">
              <Film className="w-10 h-10 text-orange-500" />
              <span className="text-2xl font-cinzel font-bold gradient-text">KVC PRODUCTIONS</span>
            </motion.div>
          </Link>

          <nav className="hidden lg:flex items-center space-x-8">
            <NavLink to="/" className={({
            isActive
          }) => `font-semibold transition-colors hover:text-orange-500 ${isActive ? 'text-orange-500' : 'text-foreground'}`}>Home</NavLink>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="font-semibold text-foreground hover:text-orange-500">
                  Explore <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {dropdownLinks.map(link => <DropdownMenuItem key={link.name} asChild>
                    <Link to={link.path}>{link.name}</Link>
                  </DropdownMenuItem>)}
              </DropdownMenuContent>
            </DropdownMenu>

            <NavLink to="/about" className={({
            isActive
          }) => `font-semibold transition-colors hover:text-orange-500 ${isActive ? 'text-orange-500' : 'text-foreground'}`}>About</NavLink>
            <NavLink to="/contact" className={({
            isActive
          }) => `font-semibold transition-colors hover:text-orange-500 ${isActive ? 'text-orange-500' : 'text-foreground'}`}>Contact</NavLink>
          </nav>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Link to="/auth">
              <Button variant="outline" className="hidden lg:flex border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white dark:hover:text-black">
                <UserCircle className="w-5 h-5 mr-2" />
                Login
              </Button>
            </Link>
            <button className="lg:hidden text-foreground" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {isMenuOpen && <motion.nav initial={{
        opacity: 0,
        y: -20
      }} animate={{
        opacity: 1,
        y: 0
      }} className="lg:hidden mt-4 bg-background/95 backdrop-blur-sm rounded-lg p-4 space-y-2">
            <NavLink to="/" className="block w-full text-left py-2 font-semibold text-foreground hover:text-orange-500" onClick={() => setIsMenuOpen(false)}>Home</NavLink>
            {dropdownLinks.map(link => <NavLink key={link.name} to={link.path} className="block w-full text-left py-2 font-semibold text-foreground hover:text-orange-500" onClick={() => setIsMenuOpen(false)}>{link.name}</NavLink>)}
            <NavLink to="/about" className="block w-full text-left py-2 font-semibold text-foreground hover:text-orange-500" onClick={() => setIsMenuOpen(false)}>About</NavLink>
            <NavLink to="/contact" className="block w-full text-left py-2 font-semibold text-foreground hover:text-orange-500" onClick={() => setIsMenuOpen(false)}>Contact</NavLink>
            <Link to="/auth" className="w-full">
              <Button variant="outline" className="w-full mt-4 border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white dark:hover:text-black" onClick={() => setIsMenuOpen(false)}>
                Login / Signup
              </Button>
            </Link>
          </motion.nav>}
      </div>
    </motion.header>;
};
export default Header;