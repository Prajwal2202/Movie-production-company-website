
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Calendar, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Movies = () => {
  const { toast } = useToast();

  const movies = [
    {
      title: "Shadows of Tomorrow",
      genre: "Sci-Fi Thriller",
      year: "2024",
      rating: "8.5",
      description: "A gripping tale of humanity's struggle against an uncertain future.",
      status: "In Production"
    },
    {
      title: "Hearts Entwined",
      genre: "Romantic Drama",
      year: "2023",
      rating: "9.2",
      description: "A heartwarming story of love that transcends all boundaries.",
      status: "Released"
    },
    {
      title: "The Last Stand",
      genre: "Action Adventure",
      year: "2023",
      rating: "8.8",
      description: "An epic action-packed journey of courage and determination.",
      status: "Released"
    },
    {
      title: "Whispers in the Wind",
      genre: "Mystery Drama",
      year: "2024",
      rating: "8.7",
      description: "A mysterious tale that keeps audiences on the edge of their seats.",
      status: "Post-Production"
    },
    {
      title: "City of Dreams",
      genre: "Urban Comedy",
      year: "2022",
      rating: "8.3",
      description: "A lighthearted comedy about chasing dreams in the big city.",
      status: "Released"
    },
    {
      title: "Beyond the Horizon",
      genre: "Adventure Drama",
      year: "2024",
      rating: "9.0",
      description: "An inspiring journey of discovery and self-realization.",
      status: "Coming Soon"
    }
  ];

  const handleWatchTrailer = (movieTitle) => {
    toast({
      title: `🎬 ${movieTitle} Trailer`,
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <section id="movies" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-cinzel font-bold mb-6">
            <span className="gradient-text">Our Cinematic Portfolio</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover our collection of compelling stories brought to life through 
            exceptional filmmaking and innovative storytelling techniques.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {movies.map((movie, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-effect rounded-lg overflow-hidden movie-card-hover group"
            >
              <div className="relative">
                <img  
                  alt={`${movie.title} movie poster`}
                  className="w-full h-64 object-cover"
                 src="https://images.unsplash.com/photo-1610616817237-dff4b556cce6" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Button
                    onClick={() => handleWatchTrailer(movie.title)}
                    className="bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Watch Trailer
                  </Button>
                </div>
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    movie.status === 'Released' ? 'bg-green-500 text-white' :
                    movie.status === 'In Production' ? 'bg-blue-500 text-white' :
                    movie.status === 'Post-Production' ? 'bg-yellow-500 text-black' :
                    'bg-purple-500 text-white'
                  }`}>
                    {movie.status}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-cinzel font-semibold mb-2 text-white">
                  {movie.title}
                </h3>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-orange-500 font-medium">{movie.genre}</span>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-400 text-sm">{movie.year}</span>
                  </div>
                </div>
                <div className="flex items-center mb-3">
                  <Star className="w-4 h-4 text-yellow-500 mr-1" />
                  <span className="text-yellow-500 font-semibold">{movie.rating}</span>
                  <span className="text-gray-400 text-sm ml-1">/10</span>
                </div>
                <p className="text-gray-300 text-sm leading-relaxed">
                  {movie.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            onClick={() => toast({
              title: "🎬 Full Portfolio Coming Soon!",
              description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
            })}
            size="lg"
            className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-black font-semibold px-8 py-3"
          >
            View Full Portfolio
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Movies;
