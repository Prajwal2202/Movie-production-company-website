import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const PageLayout = ({ children, title = "KVC Productions", description = "Crafting captivating cinematic experiences." }) => {
  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
      </Helmet>
      <Header />
      <main className="page-container">{children}</main>
      <Footer />
    </>
  );
};

export default PageLayout;