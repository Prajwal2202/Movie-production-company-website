
import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Heart, Zap, Globe } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Camera,
      title: "Innovative Storytelling",
      description: "We bring fresh perspectives and creative narratives to every project, ensuring each story captivates and inspires."
    },
    {
      icon: Heart,
      title: "Passionate Craftsmanship",
      description: "Our team pours heart and soul into every frame, creating authentic emotional connections with audiences."
    },
    {
      icon: Zap,
      title: "High-Quality Production",
      description: "State-of-the-art equipment and cutting-edge techniques deliver cinematic excellence in every production."
    },
    {
      icon: Globe,
      title: "Global Reach",
      description: "Our films resonate with diverse audiences worldwide, transcending cultural boundaries through universal storytelling."
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-cinzel font-bold mb-6">
            <span className="gradient-text">About KVC Productions</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            KVC Productions is a dynamic movie production company dedicated to crafting captivating 
            cinematic experiences. We specialize in bringing compelling stories to life on screen, 
            from gripping dramas to heartwarming comedies and thrilling action films.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img  
              alt="KVC Productions team working on film set with professional equipment"
              className="rounded-lg shadow-2xl w-full h-96 object-cover"
             src="https://images.unsplash.com/photo-1703463890291-e65bbfbe358c" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h3 className="text-3xl font-cinzel font-semibold gradient-text">
              Our Vision
            </h3>
            <p className="text-lg text-gray-300 leading-relaxed">
              With a passion for innovative storytelling and high-quality production, 
              KVC delivers memorable films that resonate with audiences worldwide. 
              We believe in the power of cinema to inspire, entertain, and create 
              lasting emotional connections.
            </p>
            <p className="text-lg text-gray-300 leading-relaxed">
              Our commitment to excellence drives us to push creative boundaries 
              while maintaining the highest production standards. Every project 
              is an opportunity to tell a story that matters.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-effect rounded-lg p-6 text-center hover:scale-105 transition-transform duration-300"
            >
              <feature.icon className="w-12 h-12 text-orange-500 mx-auto mb-4" />
              <h4 className="text-xl font-semibold mb-3 text-white">{feature.title}</h4>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
