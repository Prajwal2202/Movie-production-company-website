import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Film } from 'lucide-react';

const featuredMovies = [
  { id: 'krishnam-pranaya-sakhi', title: "Krishnam Pranaya Sakhi", description: 'A fresh and loving romance story' },
  { id: 'dandupalya-1', title: "Dandupalya 1", description: 'A gritty and intense crime thriller' },
  { id: 'dandupalya-2', title: "Dandupalya 2", description: 'The brutal sequel to the infamous crime story' },
];

const allMovies = [
    ...featuredMovies,
    { id: 'dandupalya-3', title: "Dandupalya 3", description: 'Uncovering more dark secrets of the Dandupalya gang' },
    { id: 'dandupalya-4', title: "Dandupalya 4", description: 'The thrilling conclusion to the Dandupalya series' },
]

const FeaturedMovies = () => {

  const handleExploreAll = () => {
    const moviesSection = document.getElementById('all-movies-section');
    if (moviesSection) {
        moviesSection.scrollIntoView({ behavior: 'smooth' });
    }
  }

  return (
    <div id="featured-movies">
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-cinzel font-bold mb-4 gradient-text">Featured Films</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore our critically acclaimed and fan-favorite cinematic creations.
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredMovies.map((movie, index) => (
            <motion.div
              key={movie.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Link to={`/movie/${movie.id}`}>
                <div className="relative h-96 rounded-lg overflow-hidden group glass-effect movie-card-hover">
                   <img  alt={`${movie.title} poster`} className="absolute inset-0 w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110" src="https://images.unsplash.com/photo-1545168419-7ae9499a3e11" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-6">
                    <h3 className="text-2xl font-cinzel font-bold text-white text-shadow">{movie.title}</h3>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
        >
            <Button onClick={handleExploreAll} size="lg" className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-black font-semibold">
                <Film className="mr-2 h-5 w-5"/>
                Explore All Movies
            </Button>
        </motion.div>
      </div>
    </section>

    <section id="all-movies-section" className="py-20 bg-gray-900/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-cinzel font-bold mb-4 gradient-text">Our Complete Filmography</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A look at every story we've brought to the big screen.
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allMovies.map((movie, index) => (
            <motion.div
              key={movie.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Link to={`/movie/${movie.id}`}>
                <div className="relative h-96 rounded-lg overflow-hidden group glass-effect movie-card-hover">
                   <img  alt={`${movie.title} poster`} className="absolute inset-0 w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110" src="https://images.unsplash.com/photo-1545168419-7ae9499a3e11" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-6">
                    <h3 className="text-2xl font-cinzel font-bold text-white text-shadow">{movie.title}</h3>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        </div>
    </section>
    </div>
  );
};

export default FeaturedMovies;