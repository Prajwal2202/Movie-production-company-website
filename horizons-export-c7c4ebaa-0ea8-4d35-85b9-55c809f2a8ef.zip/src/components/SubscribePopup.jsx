import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const SubscribePopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const hasVisited = sessionStorage.getItem('kvc_subscribed_popup');
    if (!hasVisited) {
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 5000); // Popup after 5 seconds
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    sessionStorage.setItem('kvc_subscribed_popup', 'true');
    setIsOpen(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "✅ Subscribed!",
      description: "Thanks for joining! You'll get the latest KVC Productions news.",
    });
    handleClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4"
          onClick={handleClose}
        >
          <motion.div
            initial={{ scale: 0.5, y: -100 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.5, y: -100 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="relative bg-gray-900 border border-orange-500/50 rounded-lg shadow-2xl p-8 max-w-md w-full text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
            <h2 className="text-3xl font-cinzel font-bold mb-4 gradient-text">Stay Updated!</h2>
            <p className="text-gray-300 mb-6">
              Subscribe to our newsletter for exclusive updates, behind-the-scenes content, and upcoming movie news.
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="text"
                placeholder="Your Name"
                className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 focus:ring-orange-500 focus:border-orange-500"
                required
              />
              <Input
                type="email"
                placeholder="Your Email Address"
                className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 focus:ring-orange-500 focus:border-orange-500"
                required
              />
              <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 text-black font-semibold">
                Subscribe Now
              </Button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SubscribePopup;