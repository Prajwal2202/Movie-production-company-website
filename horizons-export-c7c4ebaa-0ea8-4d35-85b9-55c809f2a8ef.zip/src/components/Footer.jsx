import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Film, Facebook, Twitter, Instagram, Youtube, Mail, Phone } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Footer = () => {
  const { toast } = useToast();

  const handleSocialClick = (platform) => {
    toast({
      title: `🔗 ${platform} Link`,
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const socialLinks = [
    { icon: Facebook, name: 'Facebook', href: '#' },
    { icon: Twitter, name: 'Twitter', href: 'https://x.com/KvcProduction' },
    { icon: Instagram, name: 'Instagram', href: 'https://www.instagram.com/kvc_production/' },
    { icon: Youtube, name: 'YouTube', href: 'https://www.youtube.com/@KVCProductions' }
  ];

  const quickLinks = [
    { name: 'About Us', path: '/about' },
    { name: 'Our Movies', path: '/movies' },
    { name: 'The Director', path: '/director' },
    { name: 'News & Media', path: '/news' },
    { name: 'Contact Us', path: '/contact' }
  ];

  const legalLinks = [
    { name: 'Privacy Policy', path: '#' },
    { name: 'Terms of Service', path: '#' },
  ];

  return (
    <footer className="bg-secondary text-secondary-foreground border-t">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="space-y-4"
          >
            <Link to="/" className="flex items-center space-x-3">
              <Film className="w-10 h-10 text-orange-500" />
              <span className="text-2xl font-cinzel font-bold gradient-text">KVC PRODUCTIONS</span>
            </Link>
            <p className="text-muted-foreground leading-relaxed">
              Crafting captivating cinematic experiences for audiences worldwide.
            </p>
            <div className="flex space-x-4 pt-2">
              {socialLinks.map((social) => (
                <motion.a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 bg-background hover:bg-orange-500 rounded-full flex items-center justify-center transition-colors shadow-md"
                  onClick={(e) => {
                    if (social.href === '#') {
                      e.preventDefault();
                      handleSocialClick(social.name);
                    }
                  }}
                >
                  <social.icon className="w-5 h-5 text-foreground hover:text-white" />
                </motion.a>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4 font-cinzel">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link to={link.path} className="text-muted-foreground hover:text-orange-500 transition-colors">{link.name}</Link>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4 font-cinzel">Contact Info</h3>
            <div className="space-y-4 text-muted-foreground">
              <a href="mailto:kvcproduction03@gmail.com" className="flex items-center space-x-3 hover:text-orange-500">
                <Mail className="w-5 h-5 text-orange-500" />
                <span>kvcproduction03@gmail.com</span>
              </a>
              <a href="tel:+919380561675" className="flex items-center space-x-3 hover:text-orange-500">
                <Phone className="w-5 h-5 text-orange-500" />
                <span>+91 9380561675</span>
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4 font-cinzel">Legal</h3>
            <ul className="space-y-3">
              {legalLinks.map((link) => (
                <li key={link.name}>
                  <Link to={link.path} className="text-muted-foreground hover:text-orange-500 transition-colors">{link.name}</Link>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="border-t mt-12 pt-8 text-center"
        >
          <p className="text-muted-foreground">
            © {new Date().getFullYear()} KVC Productions. All Rights Reserved.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;