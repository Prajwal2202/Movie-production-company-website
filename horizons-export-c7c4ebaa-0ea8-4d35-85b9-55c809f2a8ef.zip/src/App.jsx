import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import PageLayout from '@/components/PageLayout';
import HomePage from '@/pages/HomePage';
import MoviesListPage from '@/pages/MoviesListPage';
import MoviePage from '@/pages/MoviePage';
import DirectorPage from '@/pages/DirectorPage';
import UpcomingMoviePage from '@/pages/UpcomingMoviePage';
import AboutPage from '@/pages/AboutPage';
import ProducersPage from '@/pages/ProducersPage';
import NewsPage from '@/pages/NewsPage';
import ContactPage from '@/pages/ContactPage';
import AuthPage from '@/pages/AuthPage';
import NotFoundPage from '@/pages/NotFoundPage';
import SubscribePopup from '@/components/SubscribePopup';

function App() {
  return (
    <Router>
      <Toaster />
      <SubscribePopup />
      <Routes>
        <Route path="/" element={<PageLayout><HomePage /></PageLayout>} />
        <Route path="/movies" element={<PageLayout><MoviesListPage /></PageLayout>} />
        <Route path="/movie/:id" element={<PageLayout><MoviePage /></PageLayout>} />
        <Route path="/director" element={<PageLayout><DirectorPage /></PageLayout>} />
        <Route path="/upcoming" element={<PageLayout><UpcomingMoviePage /></PageLayout>} />
        <Route path="/about" element={<PageLayout><AboutPage /></PageLayout>} />
        <Route path="/producers" element={<PageLayout><ProducersPage /></PageLayout>} />
        <Route path="/news" element={<PageLayout><NewsPage /></PageLayout>} />
        <Route path="/contact" element={<PageLayout><ContactPage /></PageLayout>} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Router>
  );
}

export default App;